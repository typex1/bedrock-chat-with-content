#!/bin/bash

source venv/bin/activate
streamlit run app.py
